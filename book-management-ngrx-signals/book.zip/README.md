# BookManagement with NGRX simple without http calls

![ngrx](img/1.png)
![ngrx](img/2.png)
![ngrx](img/3.png)



